Easy!Appointments - WordPress Plugin 

This plugin aims to bridge Easy!Appointments with WordPress and facilitate users in the integration of the appointment booking system to their WP pages. It offers useful functions such as the installation of Easy!Appointments directly from WordPress' backend, the link of an existing installation and of course the display of the appointment booking wizard with the use of a simple shortcode.

*Minimum Requirements: WordPress v4.0 & PHP v5.3*

Linking Easy!Appointments & WordPress

Once the plugin is installed and activated a new menu entry becomes available under "Settings >> Easy!Appointments" (wp-admin). This is the main page of the plugin and it allows users to create new installations or link existing ones with their websites. Easy!Appointments must be linked with WordPress before being able to use the booking shortcode.

Applying The Shortcode

WordPress supports the use of custom [shortcodes](https://www.smashingmagazine.com/2012/05/wordpress-shortcodes-complete-guide) which enable plugins to insert custom content into a page. This plugin takes advantage of this functionality and inserts an iframe that points to the booking wizard of Easy!Appointments and can be used directly within pages or posts so that customers can book appointments without ever leaving the website.

```
[easyappointments width="100%" height="500px" style="border: 5px solid #1A865F; box-shadow: #454545 1px 1px 5px;"]
```

The "width", "height" and "style" attributes are optional but they can help to re-adjust the display of the iframe so that it better suits the active theme.


